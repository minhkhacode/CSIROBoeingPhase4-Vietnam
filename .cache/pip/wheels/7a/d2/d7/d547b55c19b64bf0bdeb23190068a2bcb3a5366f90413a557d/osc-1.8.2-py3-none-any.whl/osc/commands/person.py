import osc.commandline


class PersonCommand(osc.commandline.OscCommand):
    """
    Manage persons
    """

    name = "person"

    def run(self, args):
        pass
