import osc.commandline


class RepoCommand(osc.commandline.OscCommand):
    """
    Manage repositories in project meta
    """

    name = "repo"

    def run(self, args):
        pass
